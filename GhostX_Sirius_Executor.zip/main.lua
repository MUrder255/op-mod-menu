
-- GhostX Sirius Executor Bootstrap
-- This file initializes Sirius UI and loads all modules dynamically.

local Sirius = loadstring(game:HttpGet("https://raw.githubusercontent.com/shlexware/Sirius/request/library/loader.lua"))()
local Gui = Sirius:CreateWindow("GhostX - Universal Mod Menu")

-- Auto-load all feature modules
local categories = {"combat", "visuals", "movement", "game_specific"}
for _, category in ipairs(categories) do
    local path = "modules/" .. category
    local folder = listfiles(path)
    for _, file in ipairs(folder) do
        if file:match("%.lua$") then
            loadfile(file)()
        end
    end
end
