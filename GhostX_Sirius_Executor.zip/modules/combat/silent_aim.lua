
-- Silent Aim Module
local tab = Gui:CreateTab("Combat")
tab:CreateToggle({
    Name = "Silent Aim",
    CurrentValue = false,
    Callback = function(state)
        getgenv().SilentAimEnabled = state
    end
})
