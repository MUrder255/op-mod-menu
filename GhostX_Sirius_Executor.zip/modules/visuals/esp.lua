
-- ESP Module
local tab = Gui:CreateTab("Visuals")
tab:CreateToggle({
    Name = "ESP",
    CurrentValue = true,
    Callback = function(state)
        getgenv().ESPEnabled = state
    end
})
