
-- Speed Hack Module
local tab = Gui:CreateTab("Movement")
tab:CreateSlider({
    Name = "Speed",
    Range = {16, 100},
    Increment = 1,
    CurrentValue = 16,
    Callback = function(value)
        game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = value
    end
})
